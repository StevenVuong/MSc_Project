The original code was executed in jupyter notebook on Google Colaboratory.
The .ipynb files can be found in the 'jupyter_notebook_files' folder. These
individual files were also exported as .py files and can be found in the
'python_files' folder.

Note that the patient data was downloaded into my local google drive
and can be found at https://www.ppmi-info.org/

There are a few jupyter notebook files, each of which have their own 
function. These are listed below in the format 'name':'description' :

- 'Step1.ipynb' : Perform pre-processing, include loading the .DCM files, 
  skull-stripping, cropping, augmenting and saving to array after checking
  the processed brain scan is of the right pixel dimensions (160, 160, 160).
  Also saving the corresponding patient information into array, including 
  their age, gender, class (parkinson's disease or healthy) and finally
  saving these variables to a .pkl file to be used in a classification model

-  'misc2(age_sex_model).ipynb' : Loads the .csv file and extracts patient 
   information. Here we have our age/sex model with data-preprocessing and 
   training/testing the model

-  'misc3(2d).ipynb' : Here we run the 2D CNN model (ignore the description of
   using cv2 in the title). Steps include taking the 86th slice, normalising and then 
   running it through a 2D CNN. With training and testing included.

-  'misc5(gaussian_mask).ipynb': We have here the 3D CNN model, along with methods to
   index the slices, taking the mid-brain region and concatenate the different 
   3D MRI scans to train and test the 3D CNN on. This also includes the Gaussian Masking step

Things to Note:

- There is no code to perform cross-validation. This was conducted manually where
  the accuracy of each run was taken and averaged over 10 runs (with randomised training/test 
  sets each time) to get the cross-validation score. Rather primitive but by definition is 
  what k-fold cross-validation is.

Hope you enjoy, for any questions please feel free to contact me at 'steven.vuong@kcl.ac.uk'

Acknowledgement & thanks to:
- Google Colab for their great enabling tools
- Dr.Lam, Guangyu Jia for their wisdom
- Informatics department for the resources & teaching aid

Student ID: 1871066
Steven Vuong, 14/08/2019